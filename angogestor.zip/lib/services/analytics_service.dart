import '../models/task.dart';
import '../models/project.dart';
import 'data_service.dart';

class AnalyticsService {
  static AnalyticsService? _instance;
  static AnalyticsService get instance => _instance ??= AnalyticsService._internal();
  AnalyticsService._internal();

  final DataService _dataService = DataService.instance;

  // Daily productivity metrics
  Future<DailyStats> getDailyStats() async {
    final tasks = await _dataService.getTasks();
    final today = DateTime.now();
    
    final todayTasks = tasks.where((task) => task.isDueToday).toList();
    final completedTodayTasks = todayTasks.where((task) => task.isCompleted).toList();
    final overdueTasks = tasks.where((task) => task.isOverdue).toList();
    
    return DailyStats(
      totalTasksToday: todayTasks.length,
      completedTasksToday: completedTodayTasks.length,
      overdueTasksCount: overdueTasks.length,
      completionRate: todayTasks.isEmpty ? 0.0 : (completedTodayTasks.length / todayTasks.length) * 100,
    );
  }

  // Weekly productivity analysis
  Future<WeeklyStats> getWeeklyStats() async {
    final tasks = await _dataService.getTasks();
    final now = DateTime.now();
    final weekStart = now.subtract(Duration(days: now.weekday - 1));
    final weekEnd = weekStart.add(const Duration(days: 6));
    
    final weekTasks = tasks.where((task) {
      return task.createdAt.isAfter(weekStart) && task.createdAt.isBefore(weekEnd);
    }).toList();
    
    final completedWeekTasks = weekTasks.where((task) => task.isCompleted).toList();
    
    return WeeklyStats(
      totalTasksThisWeek: weekTasks.length,
      completedTasksThisWeek: completedWeekTasks.length,
      weeklyCompletionRate: weekTasks.isEmpty ? 0.0 : (completedWeekTasks.length / weekTasks.length) * 100,
    );
  }

  // Project-based analytics
  Future<List<ProjectStats>> getProjectStats() async {
    final tasks = await _dataService.getTasks();
    final projects = await _dataService.getProjects();
    
    List<ProjectStats> projectStatsList = [];
    
    for (Project project in projects) {
      final projectTasks = tasks.where((task) => task.projectId == project.id).toList();
      final completedTasks = projectTasks.where((task) => task.isCompleted).toList();
      final overdueTasks = projectTasks.where((task) => task.isOverdue).toList();
      
      projectStatsList.add(ProjectStats(
        project: project,
        totalTasks: projectTasks.length,
        completedTasks: completedTasks.length,
        overdueTasks: overdueTasks.length,
        completionPercentage: projectTasks.isEmpty ? 0.0 : (completedTasks.length / projectTasks.length) * 100,
      ));
    }
    
    return projectStatsList;
  }

  // Priority-based analytics
  Future<PriorityStats> getPriorityStats() async {
    final tasks = await _dataService.getTasks();
    
    final highPriorityTasks = tasks.where((task) => task.priority == TaskPriority.high).toList();
    final mediumPriorityTasks = tasks.where((task) => task.priority == TaskPriority.medium).toList();
    final lowPriorityTasks = tasks.where((task) => task.priority == TaskPriority.low).toList();
    
    return PriorityStats(
      highPriorityCount: highPriorityTasks.length,
      mediumPriorityCount: mediumPriorityTasks.length,
      lowPriorityCount: lowPriorityTasks.length,
      highPriorityCompleted: highPriorityTasks.where((task) => task.isCompleted).length,
      mediumPriorityCompleted: mediumPriorityTasks.where((task) => task.isCompleted).length,
      lowPriorityCompleted: lowPriorityTasks.where((task) => task.isCompleted).length,
    );
  }

  // Productivity insights
  Future<List<String>> getProductivityInsights() async {
    final dailyStats = await getDailyStats();
    final weeklyStats = await getWeeklyStats();
    final priorityStats = await getPriorityStats();
    
    List<String> insights = [];
    
    // Completion rate insights
    if (dailyStats.completionRate >= 80) {
      insights.add('🎉 Excelente! Você completou ${dailyStats.completionRate.toStringAsFixed(0)}% das tarefas de hoje');
    } else if (dailyStats.completionRate >= 50) {
      insights.add('👍 Bom progresso! ${dailyStats.completionRate.toStringAsFixed(0)}% das tarefas concluídas hoje');
    } else if (dailyStats.completionRate > 0) {
      insights.add('💪 Continue! ${dailyStats.completionRate.toStringAsFixed(0)}% das tarefas concluídas hoje');
    }
    
    // Overdue tasks warning
    if (dailyStats.overdueTasksCount > 0) {
      insights.add('⚠️ Você tem ${dailyStats.overdueTasksCount} tarefa(s) atrasada(s)');
    }
    
    // Weekly performance
    if (weeklyStats.weeklyCompletionRate >= 70) {
      insights.add('📈 Semana produtiva! ${weeklyStats.weeklyCompletionRate.toStringAsFixed(0)}% de conclusão');
    }
    
    // Priority insights
    if (priorityStats.highPriorityCount > 0) {
      final highPriorityRate = (priorityStats.highPriorityCompleted / priorityStats.highPriorityCount) * 100;
      if (highPriorityRate >= 80) {
        insights.add('🔥 Ótimo foco em tarefas prioritárias!');
      } else if (highPriorityRate < 50) {
        insights.add('🎯 Considere focar mais nas tarefas de alta prioridade');
      }
    }
    
    return insights;
  }
}

// Data classes for analytics
class DailyStats {
  final int totalTasksToday;
  final int completedTasksToday;
  final int overdueTasksCount;
  final double completionRate;

  DailyStats({
    required this.totalTasksToday,
    required this.completedTasksToday,
    required this.overdueTasksCount,
    required this.completionRate,
  });
}

class WeeklyStats {
  final int totalTasksThisWeek;
  final int completedTasksThisWeek;
  final double weeklyCompletionRate;

  WeeklyStats({
    required this.totalTasksThisWeek,
    required this.completedTasksThisWeek,
    required this.weeklyCompletionRate,
  });
}

class ProjectStats {
  final Project project;
  final int totalTasks;
  final int completedTasks;
  final int overdueTasks;
  final double completionPercentage;

  ProjectStats({
    required this.project,
    required this.totalTasks,
    required this.completedTasks,
    required this.overdueTasks,
    required this.completionPercentage,
  });
}

class PriorityStats {
  final int highPriorityCount;
  final int mediumPriorityCount;
  final int lowPriorityCount;
  final int highPriorityCompleted;
  final int mediumPriorityCompleted;
  final int lowPriorityCompleted;

  PriorityStats({
    required this.highPriorityCount,
    required this.mediumPriorityCount,
    required this.lowPriorityCount,
    required this.highPriorityCompleted,
    required this.mediumPriorityCompleted,
    required this.lowPriorityCompleted,
  });
}