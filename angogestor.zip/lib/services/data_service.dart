import 'dart:convert';
import 'package:shared_preferences/shared_preferences.dart';
import 'package:flutter/material.dart';
import '../models/task.dart';
import '../models/project.dart';
import '../models/app_settings.dart';

class DataService {
  static const String _tasksKey = 'tasks';
  static const String _projectsKey = 'projects';
  static const String _settingsKey = 'settings';

  static DataService? _instance;
  static DataService get instance => _instance ??= DataService._internal();
  DataService._internal();

  // Cache for better performance
  List<Task>? _tasksCache;
  List<Project>? _projectsCache;
  AppSettings? _settingsCache;

  // Tasks management
  Future<List<Task>> getTasks() async {
    if (_tasksCache != null) return _tasksCache!;
    
    final prefs = await SharedPreferences.getInstance();
    final tasksJson = prefs.getString(_tasksKey);
    
    if (tasksJson == null) {
      _tasksCache = _getDefaultTasks();
      await saveTasks(_tasksCache!);
      return _tasksCache!;
    }
    
    final List<dynamic> tasksList = json.decode(tasksJson);
    _tasksCache = tasksList.map((taskJson) => Task.fromJson(taskJson)).toList();
    return _tasksCache!;
  }

  Future<void> saveTasks(List<Task> tasks) async {
    final prefs = await SharedPreferences.getInstance();
    final tasksJson = json.encode(tasks.map((task) => task.toJson()).toList());
    await prefs.setString(_tasksKey, tasksJson);
    _tasksCache = tasks;
  }

  Future<void> addTask(Task task) async {
    final tasks = await getTasks();
    tasks.add(task);
    await saveTasks(tasks);
  }

  Future<void> updateTask(Task updatedTask) async {
    final tasks = await getTasks();
    final index = tasks.indexWhere((task) => task.id == updatedTask.id);
    if (index != -1) {
      tasks[index] = updatedTask;
      await saveTasks(tasks);
    }
  }

  Future<void> deleteTask(String taskId) async {
    final tasks = await getTasks();
    tasks.removeWhere((task) => task.id == taskId);
    await saveTasks(tasks);
  }

  // Projects management
  Future<List<Project>> getProjects() async {
    if (_projectsCache != null) return _projectsCache!;
    
    final prefs = await SharedPreferences.getInstance();
    final projectsJson = prefs.getString(_projectsKey);
    
    if (projectsJson == null) {
      _projectsCache = Project.getDefaultProjects();
      await saveProjects(_projectsCache!);
      return _projectsCache!;
    }
    
    final List<dynamic> projectsList = json.decode(projectsJson);
    _projectsCache = projectsList.map((projectJson) => Project.fromJson(projectJson)).toList();
    return _projectsCache!;
  }

  Future<void> saveProjects(List<Project> projects) async {
    final prefs = await SharedPreferences.getInstance();
    final projectsJson = json.encode(projects.map((project) => project.toJson()).toList());
    await prefs.setString(_projectsKey, projectsJson);
    _projectsCache = projects;
  }

  Future<Project?> getProjectById(String projectId) async {
    final projects = await getProjects();
    try {
      return projects.firstWhere((project) => project.id == projectId);
    } catch (e) {
      return null;
    }
  }

  // Settings management
  Future<AppSettings> getSettings() async {
    if (_settingsCache != null) return _settingsCache!;
    
    final prefs = await SharedPreferences.getInstance();
    final settingsJson = prefs.getString(_settingsKey);
    
    if (settingsJson == null) {
      _settingsCache = AppSettings();
      await saveSettings(_settingsCache!);
      return _settingsCache!;
    }
    
    _settingsCache = AppSettings.fromJson(json.decode(settingsJson));
    return _settingsCache!;
  }

  Future<void> saveSettings(AppSettings settings) async {
    final prefs = await SharedPreferences.getInstance();
    final settingsJson = json.encode(settings.toJson());
    await prefs.setString(_settingsKey, settingsJson);
    _settingsCache = settings;
  }

  // Clear cache (useful for data refresh)
  void clearCache() {
    _tasksCache = null;
    _projectsCache = null;
    _settingsCache = null;
  }

  // Default sample tasks
  List<Task> _getDefaultTasks() {
    final now = DateTime.now();
    return [
      Task(
        id: '1',
        title: 'Revisar apresentação para reunião',
        description: 'Preparar slides e pontos principais para discussão',
        dueDate: now.add(const Duration(hours: 2)),
        priority: TaskPriority.high,
        projectId: 'work',
        createdAt: now.subtract(const Duration(days: 1)),
      ),
      Task(
        id: '2',
        title: 'Fazer compras no supermercado',
        description: 'Leite, pão, frutas, verduras',
        dueDate: now.add(const Duration(days: 1)),
        priority: TaskPriority.medium,
        projectId: 'personal',
        createdAt: now.subtract(const Duration(hours: 6)),
      ),
      Task(
        id: '3',
        title: 'Estudar Flutter avançado',
        description: 'Concluir módulo sobre animações e state management',
        dueDate: now.add(const Duration(days: 3)),
        priority: TaskPriority.high,
        projectId: 'study',
        createdAt: now.subtract(const Duration(days: 2)),
      ),
      Task(
        id: '4',
        title: 'Agendar consulta médica',
        description: 'Check-up anual com clínico geral',
        priority: TaskPriority.low,
        projectId: 'personal',
        createdAt: now.subtract(const Duration(hours: 12)),
      ),
      Task(
        id: '5',
        title: 'Finalizar relatório mensal',
        description: 'Compilar dados de vendas e criar gráficos',
        dueDate: now.subtract(const Duration(days: 1)), // Overdue task
        priority: TaskPriority.high,
        projectId: 'work',
        createdAt: now.subtract(const Duration(days: 5)),
      ),
      Task(
        id: '6',
        title: 'Ler livro de JavaScript',
        description: 'Terminar capítulos 8-10',
        dueDate: now.add(const Duration(days: 7)),
        priority: TaskPriority.medium,
        projectId: 'study',
        createdAt: now.subtract(const Duration(hours: 18)),
      ),
      Task(
        id: '7',
        title: 'Organizar mesa de trabalho',
        description: 'Limpar e organizar documentos',
        priority: TaskPriority.low,
        projectId: 'personal',
        isCompleted: true,
        createdAt: now.subtract(const Duration(days: 3)),
      ),
      Task(
        id: '8',
        title: 'Preparar código para code review',
        description: 'Refatorar e adicionar comentários',
        dueDate: now,
        priority: TaskPriority.medium,
        projectId: 'work',
        createdAt: now.subtract(const Duration(hours: 4)),
      ),
    ];
  }
}