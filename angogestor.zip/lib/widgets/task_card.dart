import 'package:flutter/material.dart';
import '../models/task.dart';
import '../models/project.dart';
import '../theme.dart';

class TaskCard extends StatelessWidget {
  final Task task;
  final Project? project;
  final VoidCallback? onTap;
  final ValueChanged<bool>? onCompletionChanged;
  final VoidCallback? onDelete;

  const TaskCard({
    super.key,
    required this.task,
    this.project,
    this.onTap,
    this.onCompletionChanged,
    this.onDelete,
  });

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final colorScheme = theme.colorScheme;
    
    return Container(
      margin: const EdgeInsets.only(bottom: 12),
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          onTap: onTap,
          borderRadius: BorderRadius.circular(16),
          child: Container(
            padding: const EdgeInsets.all(16),
            decoration: BoxDecoration(
              color: task.isCompleted 
                ? colorScheme.surface.withOpacity(0.7)
                : colorScheme.surface,
              borderRadius: BorderRadius.circular(16),
              border: Border.all(
                color: colorScheme.outline.withOpacity(0.2),
                width: 1,
              ),
              boxShadow: [
                BoxShadow(
                  color: Colors.black.withOpacity(0.03),
                  blurRadius: 8,
                  offset: const Offset(0, 2),
                ),
              ],
            ),
            child: Row(
              children: [
                // Priority indicator strip
                Container(
                  width: 4,
                  height: 48,
                  decoration: BoxDecoration(
                    color: _getPriorityColor(),
                    borderRadius: BorderRadius.circular(2),
                  ),
                ),
                const SizedBox(width: 12),
                
                // Completion checkbox
                GestureDetector(
                  onTap: () => onCompletionChanged?.call(!task.isCompleted),
                  child: AnimatedContainer(
                    duration: const Duration(milliseconds: 200),
                    width: 24,
                    height: 24,
                    decoration: BoxDecoration(
                      shape: BoxShape.circle,
                      color: task.isCompleted 
                        ? colorScheme.secondary 
                        : Colors.transparent,
                      border: Border.all(
                        color: task.isCompleted 
                          ? colorScheme.secondary 
                          : colorScheme.outline,
                        width: 2,
                      ),
                    ),
                    child: task.isCompleted
                      ? Icon(
                          Icons.check,
                          size: 16,
                          color: colorScheme.onSecondary,
                        )
                      : null,
                  ),
                ),
                const SizedBox(width: 12),
                
                // Task content
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      // Title
                      Text(
                        task.title,
                        style: theme.textTheme.titleMedium?.copyWith(
                          decoration: task.isCompleted 
                            ? TextDecoration.lineThrough 
                            : null,
                          color: task.isCompleted 
                            ? colorScheme.onSurface.withOpacity(0.6)
                            : colorScheme.onSurface,
                        ),
                        maxLines: 2,
                        overflow: TextOverflow.ellipsis,
                      ),
                      
                      // Description (if exists)
                      if (task.description.isNotEmpty) ...[
                        const SizedBox(height: 4),
                        Text(
                          task.description,
                          style: theme.textTheme.bodySmall?.copyWith(
                            color: colorScheme.onSurface.withOpacity(0.7),
                            decoration: task.isCompleted 
                              ? TextDecoration.lineThrough 
                              : null,
                          ),
                          maxLines: 2,
                          overflow: TextOverflow.ellipsis,
                        ),
                      ],
                      
                      const SizedBox(height: 8),
                      
                      // Bottom row with project badge and due date
                      Row(
                        children: [
                          // Project badge
                          if (project != null)
                            Container(
                              padding: const EdgeInsets.symmetric(
                                horizontal: 8,
                                vertical: 4,
                              ),
                              decoration: BoxDecoration(
                                color: project!.color.withOpacity(0.15),
                                borderRadius: BorderRadius.circular(8),
                              ),
                              child: Text(
                                project!.name,
                                style: theme.textTheme.labelSmall?.copyWith(
                                  color: project!.color,
                                  fontWeight: FontWeight.w600,
                                ),
                              ),
                            ),
                          
                          if (project != null && task.dueDate != null)
                            const SizedBox(width: 8),
                          
                          // Due date
                          if (task.dueDate != null)
                            Container(
                              padding: const EdgeInsets.symmetric(
                                horizontal: 8,
                                vertical: 4,
                              ),
                              decoration: BoxDecoration(
                                color: _getDueDateBackgroundColor(colorScheme),
                                borderRadius: BorderRadius.circular(8),
                              ),
                              child: Row(
                                mainAxisSize: MainAxisSize.min,
                                children: [
                                  Icon(
                                    Icons.schedule,
                                    size: 12,
                                    color: _getDueDateTextColor(colorScheme),
                                  ),
                                  const SizedBox(width: 4),
                                  Text(
                                    _formatDueDate(task.dueDate!),
                                    style: theme.textTheme.labelSmall?.copyWith(
                                      color: _getDueDateTextColor(colorScheme),
                                      fontWeight: FontWeight.w500,
                                    ),
                                  ),
                                ],
                              ),
                            ),
                          
                          const Spacer(),
                          
                          // Priority badge
                          if (task.priority != TaskPriority.medium)
                            Container(
                              padding: const EdgeInsets.symmetric(
                                horizontal: 6,
                                vertical: 2,
                              ),
                              decoration: BoxDecoration(
                                color: _getPriorityColor().withOpacity(0.15),
                                borderRadius: BorderRadius.circular(6),
                              ),
                              child: Text(
                                task.priority.displayName,
                                style: theme.textTheme.labelSmall?.copyWith(
                                  color: _getPriorityColor(),
                                  fontSize: 10,
                                  fontWeight: FontWeight.w600,
                                ),
                              ),
                            ),
                        ],
                      ),
                    ],
                  ),
                ),
                
                // Delete button (optional)
                if (onDelete != null) ...[
                  const SizedBox(width: 8),
                  IconButton(
                    onPressed: onDelete,
                    icon: Icon(
                      Icons.delete_outline,
                      size: 20,
                      color: colorScheme.error.withOpacity(0.7),
                    ),
                    padding: EdgeInsets.zero,
                    constraints: const BoxConstraints(
                      minWidth: 32,
                      minHeight: 32,
                    ),
                  ),
                ],
              ],
            ),
          ),
        ),
      ),
    );
  }

  Color _getPriorityColor() {
    switch (task.priority) {
      case TaskPriority.high:
        return const Color(0xFFe53e3e); // Error red
      case TaskPriority.medium:
        return const Color(0xFFed8936); // Warning orange
      case TaskPriority.low:
        return const Color(0xFF38a169); // Success green
    }
  }

  Color _getDueDateBackgroundColor(ColorScheme colorScheme) {
    if (task.isOverdue) {
      return colorScheme.error.withOpacity(0.1);
    } else if (task.isDueToday) {
      return colorScheme.tertiary.withOpacity(0.1);
    } else {
      return colorScheme.surfaceContainerHighest.withOpacity(0.5);
    }
  }

  Color _getDueDateTextColor(ColorScheme colorScheme) {
    if (task.isOverdue) {
      return colorScheme.error;
    } else if (task.isDueToday) {
      return colorScheme.tertiary;
    } else {
      return colorScheme.onSurface.withOpacity(0.7);
    }
  }

  String _formatDueDate(DateTime dueDate) {
    final now = DateTime.now();
    final today = DateTime(now.year, now.month, now.day);
    final tomorrow = today.add(const Duration(days: 1));
    final taskDate = DateTime(dueDate.year, dueDate.month, dueDate.day);

    if (taskDate == today) {
      return 'Hoje ${dueDate.hour.toString().padLeft(2, '0')}:${dueDate.minute.toString().padLeft(2, '0')}';
    } else if (taskDate == tomorrow) {
      return 'Amanhã ${dueDate.hour.toString().padLeft(2, '0')}:${dueDate.minute.toString().padLeft(2, '0')}';
    } else if (taskDate.isBefore(today)) {
      return 'Atrasado';
    } else {
      return '${dueDate.day}/${dueDate.month}';
    }
  }
}