class AppSettings {
  final bool isDarkMode;
  final bool notificationsEnabled;
  final String defaultProjectId;

  AppSettings({
    this.isDarkMode = false,
    this.notificationsEnabled = true,
    this.defaultProjectId = 'personal',
  });

  AppSettings copyWith({
    bool? isDarkMode,
    bool? notificationsEnabled,
    String? defaultProjectId,
  }) {
    return AppSettings(
      isDarkMode: isDarkMode ?? this.isDarkMode,
      notificationsEnabled: notificationsEnabled ?? this.notificationsEnabled,
      defaultProjectId: defaultProjectId ?? this.defaultProjectId,
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'isDarkMode': isDarkMode,
      'notificationsEnabled': notificationsEnabled,
      'defaultProjectId': defaultProjectId,
    };
  }

  factory AppSettings.fromJson(Map<String, dynamic> json) {
    return AppSettings(
      isDarkMode: json['isDarkMode'] ?? false,
      notificationsEnabled: json['notificationsEnabled'] ?? true,
      defaultProjectId: json['defaultProjectId'] ?? 'personal',
    );
  }
}