import 'package:flutter/material.dart';

class Project {
  final String id;
  final String name;
  final String description;
  final Color color;
  final DateTime createdAt;

  Project({
    required this.id,
    required this.name,
    this.description = '',
    required this.color,
    required this.createdAt,
  });

  Project copyWith({
    String? id,
    String? name,
    String? description,
    Color? color,
    DateTime? createdAt,
  }) {
    return Project(
      id: id ?? this.id,
      name: name ?? this.name,
      description: description ?? this.description,
      color: color ?? this.color,
      createdAt: createdAt ?? this.createdAt,
    );
  }

  Map<String, dynamic> toJson() {
    return {
      'id': id,
      'name': name,
      'description': description,
      'color': color.value,
      'createdAt': createdAt.toIso8601String(),
    };
  }

  factory Project.fromJson(Map<String, dynamic> json) {
    return Project(
      id: json['id'],
      name: json['name'],
      description: json['description'] ?? '',
      color: Color(json['color']),
      createdAt: DateTime.parse(json['createdAt']),
    );
  }

  static List<Project> getDefaultProjects() {
    return [
      Project(
        id: 'personal',
        name: 'Pessoal',
        description: 'Tarefas pessoais e vida cotidiana',
        color: const Color(0xFF38a169), // Success green
        createdAt: DateTime.now().subtract(const Duration(days: 30)),
      ),
      Project(
        id: 'work',
        name: 'Trabalho',
        description: 'Projetos e tarefas profissionais',
        color: const Color(0xFF1a365d), // Navy blue
        createdAt: DateTime.now().subtract(const Duration(days: 25)),
      ),
      Project(
        id: 'study',
        name: 'Estudos',
        description: 'Aprendizado e desenvolvimento pessoal',
        color: const Color(0xFFed8936), // Warning orange
        createdAt: DateTime.now().subtract(const Duration(days: 20)),
      ),
    ];
  }
}