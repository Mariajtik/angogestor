import 'package:flutter/material.dart';
import '../models/task.dart';
import '../models/project.dart';
import '../services/data_service.dart';
import '../services/analytics_service.dart';
import '../widgets/task_card.dart';
import 'package:uuid/uuid.dart';

class DashboardPage extends StatefulWidget {
  const DashboardPage({super.key});

  @override
  State<DashboardPage> createState() => _DashboardPageState();
}

class _DashboardPageState extends State<DashboardPage> with TickerProviderStateMixin {
  final DataService _dataService = DataService.instance;
  final AnalyticsService _analyticsService = AnalyticsService.instance;
  
  List<Task> _todayTasks = [];
  List<Task> _overdueTasks = [];
  DailyStats? _dailyStats;
  List<Project> _projects = [];
  bool _isLoading = true;
  
  late AnimationController _fadeController;
  late Animation<double> _fadeAnimation;

  @override
  void initState() {
    super.initState();
    _setupAnimations();
    _loadDashboardData();
  }

  void _setupAnimations() {
    _fadeController = AnimationController(
      duration: const Duration(milliseconds: 600),
      vsync: this,
    );
    _fadeAnimation = Tween<double>(begin: 0.0, end: 1.0).animate(
      CurvedAnimation(parent: _fadeController, curve: Curves.easeInOut),
    );
  }

  Future<void> _loadDashboardData() async {
    setState(() => _isLoading = true);
    
    try {
      final tasks = await _dataService.getTasks();
      final projects = await _dataService.getProjects();
      final dailyStats = await _analyticsService.getDailyStats();
      
      setState(() {
        _todayTasks = tasks.where((task) => !task.isCompleted && task.isDueToday).toList();
        _overdueTasks = tasks.where((task) => !task.isCompleted && task.isOverdue).toList();
        _projects = projects;
        _dailyStats = dailyStats;
        _isLoading = false;
      });
      
      _fadeController.forward();
    } catch (e) {
      setState(() => _isLoading = false);
    }
  }

  @override
  void dispose() {
    _fadeController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final colorScheme = theme.colorScheme;
    
    if (_isLoading) {
      return Scaffold(
        body: Center(
          child: CircularProgressIndicator(
            color: colorScheme.primary,
          ),
        ),
      );
    }

    return Scaffold(
      body: SafeArea(
        child: FadeTransition(
          opacity: _fadeAnimation,
          child: RefreshIndicator(
            onRefresh: _loadDashboardData,
            color: colorScheme.primary,
            child: CustomScrollView(
              slivers: [
                // Header
                SliverToBoxAdapter(
                  child: _buildHeader(context),
                ),
                
                // Quick stats
                SliverToBoxAdapter(
                  child: _buildQuickStats(context),
                ),
                
                // Quick add task
                SliverToBoxAdapter(
                  child: _buildQuickAdd(context),
                ),
                
                // Today\'s tasks section
                SliverToBoxAdapter(
                  child: _buildTodayTasksSection(context),
                ),
                
                // Overdue tasks (if any)
                if (_overdueTasks.isNotEmpty)
                  SliverToBoxAdapter(
                    child: _buildOverdueTasksSection(context),
                  ),
                
                // Recent projects
                SliverToBoxAdapter(
                  child: _buildRecentProjectsSection(context),
                ),
                
                // Bottom padding
                const SliverToBoxAdapter(
                  child: SizedBox(height: 100),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildHeader(BuildContext context) {
    final theme = Theme.of(context);
    final colorScheme = theme.colorScheme;
    final now = DateTime.now();
    final greeting = _getGreeting();
    
    return Container(
      padding: const EdgeInsets.all(24),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      greeting,
                      style: theme.textTheme.titleMedium?.copyWith(
                        color: colorScheme.onSurface.withOpacity(0.7),
                      ),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      'Bem-vindo ao AngoGestor',
                      style: theme.textTheme.headlineSmall?.copyWith(
                        color: colorScheme.onSurface,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ],
                ),
              ),
              
              // Notification bell
              Container(
                decoration: BoxDecoration(
                  color: colorScheme.surface,
                  shape: BoxShape.circle,
                  boxShadow: [
                    BoxShadow(
                      color: Colors.black.withOpacity(0.1),
                      blurRadius: 8,
                      offset: const Offset(0, 2),
                    ),
                  ],
                ),
                child: IconButton(
                  onPressed: () {
                    // TODO: Show notifications
                  },
                  icon: Icon(
                    Icons.notifications_outlined,
                    color: colorScheme.primary,
                  ),
                ),
              ),
            ],
          ),
          
          const SizedBox(height: 8),
          
          // Date
          Text(
            '${now.day} de ${_getMonthName(now.month)} de ${now.year}',
            style: theme.textTheme.bodyMedium?.copyWith(
              color: colorScheme.onSurface.withOpacity(0.6),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildQuickStats(BuildContext context) {
    final theme = Theme.of(context);
    final colorScheme = theme.colorScheme;
    
    if (_dailyStats == null) return const SizedBox.shrink();
    
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 24),
      child: Row(
        children: [
          // Today\'s completion
          Expanded(
            child: _buildStatCard(
              context,
              title: 'Hoje',
              value: '${_dailyStats!.completedTasksToday}/${_dailyStats!.totalTasksToday}',
              subtitle: 'concluídas',
              icon: Icons.today,
              color: colorScheme.secondary,
            ),
          ),
          
          const SizedBox(width: 16),
          
          // Completion rate
          Expanded(
            child: _buildStatCard(
              context,
              title: 'Taxa',
              value: '${_dailyStats!.completionRate.toStringAsFixed(0)}%',
              subtitle: 'conclusão',
              icon: Icons.trending_up,
              color: colorScheme.primary,
            ),
          ),
          
          const SizedBox(width: 16),
          
          // Overdue tasks
          Expanded(
            child: _buildStatCard(
              context,
              title: 'Atrasadas',
              value: '${_dailyStats!.overdueTasksCount}',
              subtitle: 'tarefas',
              icon: Icons.warning,
              color: _dailyStats!.overdueTasksCount > 0 
                ? colorScheme.error 
                : colorScheme.outline,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildStatCard(
    BuildContext context, {
    required String title,
    required String value,
    required String subtitle,
    required IconData icon,
    required Color color,
  }) {
    final theme = Theme.of(context);
    final colorScheme = theme.colorScheme;
    
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        color: color.withOpacity(0.1),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(
          color: color.withOpacity(0.2),
          width: 1,
        ),
      ),
      child: Column(
        children: [
          Icon(
            icon,
            color: color,
            size: 24,
          ),
          const SizedBox(height: 8),
          Text(
            value,
            style: theme.textTheme.titleLarge?.copyWith(
              color: color,
              fontWeight: FontWeight.bold,
            ),
          ),
          Text(
            subtitle,
            style: theme.textTheme.labelSmall?.copyWith(
              color: color.withOpacity(0.8),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildQuickAdd(BuildContext context) {
    final theme = Theme.of(context);
    final colorScheme = theme.colorScheme;
    
    return Container(
      margin: const EdgeInsets.all(24),
      child: Material(
        color: Colors.transparent,
        child: InkWell(
          onTap: _showQuickAddDialog,
          borderRadius: BorderRadius.circular(16),
          child: Container(
            padding: const EdgeInsets.all(20),
            decoration: BoxDecoration(
              gradient: LinearGradient(
                begin: Alignment.topLeft,
                end: Alignment.bottomRight,
                colors: [
                  colorScheme.primary,
                  colorScheme.primary.withOpacity(0.8),
                ],
              ),
              borderRadius: BorderRadius.circular(16),
              boxShadow: [
                BoxShadow(
                  color: colorScheme.primary.withOpacity(0.3),
                  blurRadius: 12,
                  offset: const Offset(0, 6),
                ),
              ],
            ),
            child: Row(
              children: [
                Icon(
                  Icons.add_circle_outline,
                  color: colorScheme.onPrimary,
                  size: 28,
                ),
                const SizedBox(width: 16),
                Expanded(
                  child: Column(
                    crossAxisAlignment: CrossAxisAlignment.start,
                    children: [
                      Text(
                        'Adicionar Nova Tarefa',
                        style: theme.textTheme.titleMedium?.copyWith(
                          color: colorScheme.onPrimary,
                          fontWeight: FontWeight.w600,
                        ),
                      ),
                      Text(
                        'Toque para criar uma nova tarefa',
                        style: theme.textTheme.bodySmall?.copyWith(
                          color: colorScheme.onPrimary.withOpacity(0.8),
                        ),
                      ),
                    ],
                  ),
                ),
                Icon(
                  Icons.arrow_forward_ios,
                  color: colorScheme.onPrimary,
                  size: 16,
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }

  Widget _buildTodayTasksSection(BuildContext context) {
    final theme = Theme.of(context);
    final colorScheme = theme.colorScheme;
    
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 24),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(
                Icons.today,
                color: colorScheme.primary,
                size: 20,
              ),
              const SizedBox(width: 8),
              Text(
                'Tarefas de Hoje',
                style: theme.textTheme.titleMedium?.copyWith(
                  color: colorScheme.onSurface,
                  fontWeight: FontWeight.w600,
                ),
              ),
              const Spacer(),
              if (_todayTasks.length > 3)
                TextButton(
                  onPressed: () {
                    // TODO: Navigate to tasks page with today filter
                  },
                  child: Text(
                    'Ver todas',
                    style: theme.textTheme.labelMedium?.copyWith(
                      color: colorScheme.primary,
                    ),
                  ),
                ),
            ],
          ),
          
          const SizedBox(height: 16),
          
          if (_todayTasks.isEmpty)
            Container(
              padding: const EdgeInsets.all(24),
              decoration: BoxDecoration(
                color: colorScheme.surface,
                borderRadius: BorderRadius.circular(16),
              ),
              child: Center(
                child: Column(
                  children: [
                    Icon(
                      Icons.check_circle_outline,
                      color: colorScheme.secondary,
                      size: 48,
                    ),
                    const SizedBox(height: 12),
                    Text(
                      'Nenhuma tarefa para hoje!',
                      style: theme.textTheme.titleMedium?.copyWith(
                        color: colorScheme.onSurface,
                      ),
                    ),
                    Text(
                      'Você está em dia ✨',
                      style: theme.textTheme.bodyMedium?.copyWith(
                        color: colorScheme.onSurface.withOpacity(0.7),
                      ),
                    ),
                  ],
                ),
              ),
            )
          else
            Column(
              children: _todayTasks.take(3).map((task) {
                final project = _projects.firstWhere(
                  (p) => p.id == task.projectId,
                  orElse: () => _projects.first,
                );
                
                return TaskCard(
                  task: task,
                  project: project,
                  onCompletionChanged: (isCompleted) => _toggleTaskCompletion(task),
                  onTap: () => _editTask(task),
                );
              }).toList(),
            ),
        ],
      ),
    );
  }

  Widget _buildOverdueTasksSection(BuildContext context) {
    final theme = Theme.of(context);
    final colorScheme = theme.colorScheme;
    
    return Container(
      margin: const EdgeInsets.all(24),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Icon(
                Icons.warning,
                color: colorScheme.error,
                size: 20,
              ),
              const SizedBox(width: 8),
              Text(
                'Tarefas Atrasadas',
                style: theme.textTheme.titleMedium?.copyWith(
                  color: colorScheme.error,
                  fontWeight: FontWeight.w600,
                ),
              ),
            ],
          ),
          
          const SizedBox(height: 16),
          
          Column(
            children: _overdueTasks.take(2).map((task) {
              final project = _projects.firstWhere(
                (p) => p.id == task.projectId,
                orElse: () => _projects.first,
              );
              
              return TaskCard(
                task: task,
                project: project,
                onCompletionChanged: (isCompleted) => _toggleTaskCompletion(task),
                onTap: () => _editTask(task),
              );
            }).toList(),
          ),
        ],
      ),
    );
  }

  Widget _buildRecentProjectsSection(BuildContext context) {
    final theme = Theme.of(context);
    final colorScheme = theme.colorScheme;
    
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 24),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          const SizedBox(height: 32),
          
          Row(
            children: [
              Icon(
                Icons.folder,
                color: colorScheme.primary,
                size: 20,
              ),
              const SizedBox(width: 8),
              Text(
                'Projetos Recentes',
                style: theme.textTheme.titleMedium?.copyWith(
                  color: colorScheme.onSurface,
                  fontWeight: FontWeight.w600,
                ),
              ),
            ],
          ),
          
          const SizedBox(height: 16),
          
          SizedBox(
            height: 120,
            child: ListView.builder(
              scrollDirection: Axis.horizontal,
              itemCount: _projects.length,
              itemBuilder: (context, index) {
                final project = _projects[index];
                return Container(
                  width: 200,
                  margin: EdgeInsets.only(right: index < _projects.length - 1 ? 16 : 0),
                  child: _buildProjectMiniCard(context, project),
                );
              },
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildProjectMiniCard(BuildContext context, Project project) {
    final theme = Theme.of(context);
    final colorScheme = theme.colorScheme;
    
    return Container(
      padding: const EdgeInsets.all(16),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [
            project.color.withOpacity(0.1),
            project.color.withOpacity(0.05),
          ],
        ),
        borderRadius: BorderRadius.circular(16),
        border: Border.all(
          color: project.color.withOpacity(0.2),
          width: 1,
        ),
      ),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Container(
                width: 8,
                height: 8,
                decoration: BoxDecoration(
                  color: project.color,
                  shape: BoxShape.circle,
                ),
              ),
              const SizedBox(width: 8),
              Expanded(
                child: Text(
                  project.name,
                  style: theme.textTheme.titleSmall?.copyWith(
                    color: colorScheme.onSurface,
                    fontWeight: FontWeight.w600,
                  ),
                  maxLines: 1,
                  overflow: TextOverflow.ellipsis,
                ),
              ),
            ],
          ),
          const SizedBox(height: 8),
          Text(
            project.description.isNotEmpty ? project.description : 'Sem descrição',
            style: theme.textTheme.bodySmall?.copyWith(
              color: colorScheme.onSurface.withOpacity(0.7),
            ),
            maxLines: 2,
            overflow: TextOverflow.ellipsis,
          ),
          const Spacer(),
          Text(
            'Ver projeto →',
            style: theme.textTheme.labelSmall?.copyWith(
              color: project.color,
              fontWeight: FontWeight.w600,
            ),
          ),
        ],
      ),
    );
  }

  void _showQuickAddDialog() {
    final textController = TextEditingController();
    
    showDialog(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Nova Tarefa'),
        content: TextField(
          controller: textController,
          decoration: const InputDecoration(
            hintText: 'Digite o título da tarefa...',
            border: OutlineInputBorder(),
          ),
          autofocus: true,
        ),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context),
            child: const Text('Cancelar'),
          ),
          ElevatedButton(
            onPressed: () {
              if (textController.text.trim().isNotEmpty) {
                _addQuickTask(textController.text.trim());
                Navigator.pop(context);
              }
            },
            child: const Text('Adicionar'),
          ),
        ],
      ),
    );
  }

  Future<void> _addQuickTask(String title) async {
    final newTask = Task(
      id: const Uuid().v4(),
      title: title,
      projectId: 'personal',
      createdAt: DateTime.now(),
      dueDate: DateTime.now().add(const Duration(hours: 2)),
    );
    
    await _dataService.addTask(newTask);
    _loadDashboardData();
  }

  Future<void> _toggleTaskCompletion(Task task) async {
    final updatedTask = task.copyWith(isCompleted: !task.isCompleted);
    await _dataService.updateTask(updatedTask);
    _loadDashboardData();
  }

  void _editTask(Task task) {
    // TODO: Navigate to task edit page
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('Edição de tarefa em desenvolvimento')),
    );
  }

  String _getGreeting() {
    final hour = DateTime.now().hour;
    if (hour < 12) return 'Bom dia! ☀️';
    if (hour < 18) return 'Boa tarde! 🌤️';
    return 'Boa noite! 🌙';
  }

  String _getMonthName(int month) {
    const months = [
      'Janeiro', 'Fevereiro', 'Março', 'Abril', 'Maio', 'Junho',
      'Julho', 'Agosto', 'Setembro', 'Outubro', 'Novembro', 'Dezembro'
    ];
    return months[month - 1];
  }
}