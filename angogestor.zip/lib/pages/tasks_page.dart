import 'package:flutter/material.dart';
import '../models/task.dart';
import '../models/project.dart';
import '../services/data_service.dart';
import '../widgets/task_card.dart';
import 'package:uuid/uuid.dart';

class TasksPage extends StatefulWidget {
  const TasksPage({super.key});

  @override
  State<TasksPage> createState() => _TasksPageState();
}

class _TasksPageState extends State<TasksPage> with TickerProviderStateMixin {
  final DataService _dataService = DataService.instance;
  final TextEditingController _searchController = TextEditingController();
  
  List<Task> _allTasks = [];
  List<Task> _filteredTasks = [];
  List<Project> _projects = [];
  TaskFilter _currentFilter = TaskFilter.all;
  String _selectedProjectId = '';
  bool _isLoading = true;
  
  late AnimationController _listController;
  late Animation<Offset> _slideAnimation;

  @override
  void initState() {
    super.initState();
    _setupAnimations();
    _loadData();
    _searchController.addListener(_onSearchChanged);
  }

  void _setupAnimations() {
    _listController = AnimationController(
      duration: const Duration(milliseconds: 400),
      vsync: this,
    );
    _slideAnimation = Tween<Offset>(
      begin: const Offset(0, 0.1),
      end: Offset.zero,
    ).animate(CurvedAnimation(
      parent: _listController,
      curve: Curves.easeOutQuart,
    ));
  }

  Future<void> _loadData() async {
    setState(() => _isLoading = true);
    
    try {
      final tasks = await _dataService.getTasks();
      final projects = await _dataService.getProjects();
      
      setState(() {
        _allTasks = tasks;
        _projects = projects;
        _isLoading = false;
      });
      
      _applyFilters();
      _listController.forward();
    } catch (e) {
      setState(() => _isLoading = false);
    }
  }

  void _onSearchChanged() {
    _applyFilters();
  }

  void _applyFilters() {
    List<Task> filtered = List.from(_allTasks);
    
    // Apply search filter
    if (_searchController.text.isNotEmpty) {
      final query = _searchController.text.toLowerCase();
      filtered = filtered.where((task) =>
        task.title.toLowerCase().contains(query) ||
        task.description.toLowerCase().contains(query)
      ).toList();
    }
    
    // Apply task filter
    switch (_currentFilter) {
      case TaskFilter.today:
        filtered = filtered.where((task) => task.isDueToday).toList();
        break;
      case TaskFilter.overdue:
        filtered = filtered.where((task) => task.isOverdue).toList();
        break;
      case TaskFilter.completed:
        filtered = filtered.where((task) => task.isCompleted).toList();
        break;
      case TaskFilter.pending:
        filtered = filtered.where((task) => !task.isCompleted).toList();
        break;
      case TaskFilter.all:
      default:
        break;
    }
    
    // Apply project filter
    if (_selectedProjectId.isNotEmpty) {
      filtered = filtered.where((task) => task.projectId == _selectedProjectId).toList();
    }
    
    // Sort tasks
    filtered.sort((a, b) {
      // Priority order: high > medium > low
      if (a.priority != b.priority) {
        return b.priority.index.compareTo(a.priority.index);
      }
      
      // Overdue tasks first
      if (a.isOverdue != b.isOverdue) {
        return a.isOverdue ? -1 : 1;
      }
      
      // Due date order
      if (a.dueDate != null && b.dueDate != null) {
        return a.dueDate!.compareTo(b.dueDate!);
      } else if (a.dueDate != null) {
        return -1;
      } else if (b.dueDate != null) {
        return 1;
      }
      
      // Creation date order
      return b.createdAt.compareTo(a.createdAt);
    });
    
    setState(() {
      _filteredTasks = filtered;
    });
  }

  @override
  void dispose() {
    _listController.dispose();
    _searchController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final colorScheme = theme.colorScheme;
    
    if (_isLoading) {
      return Scaffold(
        body: Center(
          child: CircularProgressIndicator(color: colorScheme.primary),
        ),
      );
    }

    return Scaffold(
      body: SafeArea(
        child: Column(
          children: [
            // Header with search
            _buildHeader(context),
            
            // Filter tabs
            _buildFilterTabs(context),
            
            // Project filter (if applicable)
            if (_selectedProjectId.isNotEmpty)
              _buildProjectFilter(context),
            
            // Task list
            Expanded(
              child: _buildTaskList(context),
            ),
          ],
        ),
      ),
      floatingActionButton: _buildFAB(context),
    );
  }

  Widget _buildHeader(BuildContext context) {
    final theme = Theme.of(context);
    final colorScheme = theme.colorScheme;
    
    return Container(
      padding: const EdgeInsets.all(24),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          // Title and stats
          Row(
            children: [
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'Tarefas',
                      style: theme.textTheme.headlineSmall?.copyWith(
                        color: colorScheme.onSurface,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      '${_filteredTasks.length} de ${_allTasks.length} tarefas',
                      style: theme.textTheme.bodyMedium?.copyWith(
                        color: colorScheme.onSurface.withOpacity(0.7),
                      ),
                    ),
                  ],
                ),
              ),
              
              // Sort button
              IconButton(
                onPressed: _showSortOptions,
                icon: Icon(
                  Icons.sort,
                  color: colorScheme.primary,
                ),
              ),
            ],
          ),
          
          const SizedBox(height: 16),
          
          // Search bar
          Container(
            decoration: BoxDecoration(
              color: colorScheme.surface,
              borderRadius: BorderRadius.circular(16),
              border: Border.all(
                color: colorScheme.outline.withOpacity(0.2),
              ),
            ),
            child: TextField(
              controller: _searchController,
              decoration: InputDecoration(
                hintText: 'Buscar tarefas...',
                hintStyle: TextStyle(
                  color: colorScheme.onSurface.withOpacity(0.5),
                ),
                prefixIcon: Icon(
                  Icons.search,
                  color: colorScheme.onSurface.withOpacity(0.5),
                ),
                suffixIcon: _searchController.text.isNotEmpty
                  ? IconButton(
                      onPressed: () {
                        _searchController.clear();
                        _applyFilters();
                      },
                      icon: Icon(
                        Icons.clear,
                        color: colorScheme.onSurface.withOpacity(0.5),
                      ),
                    )
                  : null,
                border: InputBorder.none,
                contentPadding: const EdgeInsets.symmetric(
                  horizontal: 16,
                  vertical: 16,
                ),
              ),
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildFilterTabs(BuildContext context) {
    final theme = Theme.of(context);
    final colorScheme = theme.colorScheme;
    
    return Container(
      height: 60,
      padding: const EdgeInsets.symmetric(horizontal: 24),
      child: ListView(
        scrollDirection: Axis.horizontal,
        children: TaskFilter.values.map((filter) {
          final isSelected = _currentFilter == filter;
          
          return Container(
            margin: const EdgeInsets.only(right: 12),
            child: FilterChip(
              label: Text(
                filter.displayName,
                style: TextStyle(
                  color: isSelected 
                    ? colorScheme.onPrimary 
                    : colorScheme.onSurface,
                  fontWeight: isSelected ? FontWeight.w600 : FontWeight.normal,
                ),
              ),
              selected: isSelected,
              onSelected: (selected) {
                setState(() {
                  _currentFilter = filter;
                });
                _applyFilters();
              },
              backgroundColor: colorScheme.surface,
              selectedColor: colorScheme.primary,
              checkmarkColor: colorScheme.onPrimary,
              side: BorderSide(
                color: isSelected 
                  ? colorScheme.primary 
                  : colorScheme.outline.withOpacity(0.3),
              ),
              padding: const EdgeInsets.symmetric(horizontal: 16, vertical: 8),
            ),
          );
        }).toList(),
      ),
    );
  }

  Widget _buildProjectFilter(BuildContext context) {
    final theme = Theme.of(context);
    final colorScheme = theme.colorScheme;
    final project = _projects.firstWhere((p) => p.id == _selectedProjectId);
    
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 24, vertical: 8),
      padding: const EdgeInsets.all(12),
      decoration: BoxDecoration(
        color: project.color.withOpacity(0.1),
        borderRadius: BorderRadius.circular(12),
        border: Border.all(
          color: project.color.withOpacity(0.3),
        ),
      ),
      child: Row(
        children: [
          Container(
            width: 8,
            height: 8,
            decoration: BoxDecoration(
              color: project.color,
              shape: BoxShape.circle,
            ),
          ),
          const SizedBox(width: 12),
          Text(
            'Projeto: ${project.name}',
            style: theme.textTheme.labelMedium?.copyWith(
              color: project.color,
              fontWeight: FontWeight.w600,
            ),
          ),
          const Spacer(),
          GestureDetector(
            onTap: () {
              setState(() {
                _selectedProjectId = '';
              });
              _applyFilters();
            },
            child: Icon(
              Icons.close,
              size: 16,
              color: project.color,
            ),
          ),
        ],
      ),
    );
  }

  Widget _buildTaskList(BuildContext context) {
    final theme = Theme.of(context);
    final colorScheme = theme.colorScheme;
    
    if (_filteredTasks.isEmpty) {
      return _buildEmptyState(context);
    }
    
    return RefreshIndicator(
      onRefresh: _loadData,
      color: colorScheme.primary,
      child: SlideTransition(
        position: _slideAnimation,
        child: ListView.builder(
          padding: const EdgeInsets.symmetric(horizontal: 24),
          itemCount: _filteredTasks.length,
          itemBuilder: (context, index) {
            final task = _filteredTasks[index];
            final project = _projects.firstWhere(
              (p) => p.id == task.projectId,
              orElse: () => _projects.first,
            );
            
            return TaskCard(
              task: task,
              project: project,
              onTap: () => _editTask(task),
              onCompletionChanged: (isCompleted) => _toggleTaskCompletion(task),
              onDelete: () => _deleteTask(task),
            );
          },
        ),
      ),
    );
  }

  Widget _buildEmptyState(BuildContext context) {
    final theme = Theme.of(context);
    final colorScheme = theme.colorScheme;
    
    String title;
    String subtitle;
    IconData icon;
    
    switch (_currentFilter) {
      case TaskFilter.today:
        title = 'Nenhuma tarefa para hoje';
        subtitle = 'Aproveite o dia livre! 🎉';
        icon = Icons.today;
        break;
      case TaskFilter.overdue:
        title = 'Nenhuma tarefa atrasada';
        subtitle = 'Ótimo trabalho! Você está em dia ✨';
        icon = Icons.check_circle;
        break;
      case TaskFilter.completed:
        title = 'Nenhuma tarefa concluída';
        subtitle = 'Complete algumas tarefas para vê-las aqui';
        icon = Icons.assignment_turned_in;
        break;
      case TaskFilter.pending:
        title = 'Nenhuma tarefa pendente';
        subtitle = 'Todas as tarefas foram concluídas! 🎯';
        icon = Icons.done_all;
        break;
      default:
        title = 'Nenhuma tarefa encontrada';
        subtitle = 'Crie sua primeira tarefa para começar';
        icon = Icons.assignment;
    }
    
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(32),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(
              icon,
              size: 64,
              color: colorScheme.primary.withOpacity(0.6),
            ),
            const SizedBox(height: 24),
            Text(
              title,
              style: theme.textTheme.titleLarge?.copyWith(
                color: colorScheme.onSurface,
                fontWeight: FontWeight.w600,
              ),
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 8),
            Text(
              subtitle,
              style: theme.textTheme.bodyMedium?.copyWith(
                color: colorScheme.onSurface.withOpacity(0.7),
              ),
              textAlign: TextAlign.center,
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildFAB(BuildContext context) {
    final colorScheme = Theme.of(context).colorScheme;
    
    return FloatingActionButton.extended(
      onPressed: _addNewTask,
      backgroundColor: colorScheme.primary,
      foregroundColor: colorScheme.onPrimary,
      icon: const Icon(Icons.add),
      label: const Text('Nova Tarefa'),
    );
  }

  void _showSortOptions() {
    // TODO: Implement sort options dialog
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('Opções de ordenação em desenvolvimento')),
    );
  }

  void _addNewTask() {
    _showTaskDialog();
  }

  void _editTask(Task task) {
    _showTaskDialog(task: task);
  }

  void _showTaskDialog({Task? task}) {
    final titleController = TextEditingController(text: task?.title ?? '');
    final descriptionController = TextEditingController(text: task?.description ?? '');
    TaskPriority selectedPriority = task?.priority ?? TaskPriority.medium;
    String selectedProjectId = task?.projectId ?? _projects.first.id;
    DateTime? selectedDueDate = task?.dueDate;
    
    showDialog(
      context: context,
      builder: (context) => StatefulBuilder(
        builder: (context, setDialogState) => AlertDialog(
          title: Text(task == null ? 'Nova Tarefa' : 'Editar Tarefa'),
          content: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                // Title
                TextField(
                  controller: titleController,
                  decoration: const InputDecoration(
                    labelText: 'Título',
                    border: OutlineInputBorder(),
                  ),
                ),
                const SizedBox(height: 16),
                
                // Description
                TextField(
                  controller: descriptionController,
                  decoration: const InputDecoration(
                    labelText: 'Descrição (opcional)',
                    border: OutlineInputBorder(),
                  ),
                  maxLines: 3,
                ),
                const SizedBox(height: 16),
                
                // Priority
                DropdownButtonFormField<TaskPriority>(
                  value: selectedPriority,
                  decoration: const InputDecoration(
                    labelText: 'Prioridade',
                    border: OutlineInputBorder(),
                  ),
                  items: TaskPriority.values.map((priority) {
                    return DropdownMenuItem(
                      value: priority,
                      child: Text(priority.displayName),
                    );
                  }).toList(),
                  onChanged: (value) {
                    setDialogState(() {
                      selectedPriority = value!;
                    });
                  },
                ),
                const SizedBox(height: 16),
                
                // Project
                DropdownButtonFormField<String>(
                  value: selectedProjectId,
                  decoration: const InputDecoration(
                    labelText: 'Projeto',
                    border: OutlineInputBorder(),
                  ),
                  items: _projects.map((project) {
                    return DropdownMenuItem(
                      value: project.id,
                      child: Row(
                        children: [
                          Container(
                            width: 12,
                            height: 12,
                            decoration: BoxDecoration(
                              color: project.color,
                              shape: BoxShape.circle,
                            ),
                          ),
                          const SizedBox(width: 8),
                          Text(project.name),
                        ],
                      ),
                    );
                  }).toList(),
                  onChanged: (value) {
                    setDialogState(() {
                      selectedProjectId = value!;
                    });
                  },
                ),
                const SizedBox(height: 16),
                
                // Due date
                ListTile(
                  title: Text(selectedDueDate == null 
                    ? 'Sem data de vencimento' 
                    : 'Vence em ${selectedDueDate!.day}/${selectedDueDate!.month}/${selectedDueDate!.year}'),
                  leading: const Icon(Icons.calendar_today),
                  onTap: () async {
                    final date = await showDatePicker(
                      context: context,
                      initialDate: selectedDueDate ?? DateTime.now(),
                      firstDate: DateTime.now().subtract(const Duration(days: 365)),
                      lastDate: DateTime.now().add(const Duration(days: 365)),
                    );
                    if (date != null) {
                      setDialogState(() {
                        selectedDueDate = date;
                      });
                    }
                  },
                  trailing: selectedDueDate != null 
                    ? IconButton(
                        icon: const Icon(Icons.clear),
                        onPressed: () {
                          setDialogState(() {
                            selectedDueDate = null;
                          });
                        },
                      )
                    : null,
                ),
              ],
            ),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: const Text('Cancelar'),
            ),
            ElevatedButton(
              onPressed: () {
                if (titleController.text.trim().isNotEmpty) {
                  _saveTask(
                    task: task,
                    title: titleController.text.trim(),
                    description: descriptionController.text.trim(),
                    priority: selectedPriority,
                    projectId: selectedProjectId,
                    dueDate: selectedDueDate,
                  );
                  Navigator.pop(context);
                }
              },
              child: Text(task == null ? 'Criar' : 'Salvar'),
            ),
          ],
        ),
      ),
    );
  }

  Future<void> _saveTask({
    Task? task,
    required String title,
    required String description,
    required TaskPriority priority,
    required String projectId,
    DateTime? dueDate,
  }) async {
    if (task == null) {
      // Create new task
      final newTask = Task(
        id: const Uuid().v4(),
        title: title,
        description: description,
        priority: priority,
        projectId: projectId,
        dueDate: dueDate,
        createdAt: DateTime.now(),
      );
      await _dataService.addTask(newTask);
    } else {
      // Update existing task
      final updatedTask = task.copyWith(
        title: title,
        description: description,
        priority: priority,
        projectId: projectId,
        dueDate: dueDate,
      );
      await _dataService.updateTask(updatedTask);
    }
    
    _loadData();
  }

  Future<void> _toggleTaskCompletion(Task task) async {
    final updatedTask = task.copyWith(isCompleted: !task.isCompleted);
    await _dataService.updateTask(updatedTask);
    _loadData();
  }

  Future<void> _deleteTask(Task task) async {
    final confirm = await showDialog<bool>(
      context: context,
      builder: (context) => AlertDialog(
        title: const Text('Confirmar exclusão'),
        content: Text('Deseja excluir a tarefa "${task.title}"?'),
        actions: [
          TextButton(
            onPressed: () => Navigator.pop(context, false),
            child: const Text('Cancelar'),
          ),
          ElevatedButton(
            onPressed: () => Navigator.pop(context, true),
            style: ElevatedButton.styleFrom(
              backgroundColor: Theme.of(context).colorScheme.error,
            ),
            child: const Text('Excluir'),
          ),
        ],
      ),
    );
    
    if (confirm == true) {
      await _dataService.deleteTask(task.id);
      _loadData();
    }
  }
}

enum TaskFilter {
  all,
  today,
  overdue,
  pending,
  completed;

  String get displayName {
    switch (this) {
      case TaskFilter.all:
        return 'Todas';
      case TaskFilter.today:
        return 'Hoje';
      case TaskFilter.overdue:
        return 'Atrasadas';
      case TaskFilter.pending:
        return 'Pendentes';
      case TaskFilter.completed:
        return 'Concluídas';
    }
  }
}