import 'package:flutter/material.dart';
import '../models/project.dart';
import '../services/data_service.dart';
import '../services/analytics_service.dart';
import '../widgets/project_card.dart';

class ProjectsPage extends StatefulWidget {
  const ProjectsPage({super.key});

  @override
  State<ProjectsPage> createState() => _ProjectsPageState();
}

class _ProjectsPageState extends State<ProjectsPage> with TickerProviderStateMixin {
  final DataService _dataService = DataService.instance;
  final AnalyticsService _analyticsService = AnalyticsService.instance;
  
  List<Project> _projects = [];
  List<ProjectStats> _projectStats = [];
  bool _isLoading = true;
  
  late AnimationController _fadeController;
  late Animation<double> _fadeAnimation;

  @override
  void initState() {
    super.initState();
    _setupAnimations();
    _loadData();
  }

  void _setupAnimations() {
    _fadeController = AnimationController(
      duration: const Duration(milliseconds: 500),
      vsync: this,
    );
    _fadeAnimation = Tween<double>(begin: 0.0, end: 1.0).animate(
      CurvedAnimation(parent: _fadeController, curve: Curves.easeInOut),
    );
  }

  Future<void> _loadData() async {
    setState(() => _isLoading = true);
    
    try {
      final projects = await _dataService.getProjects();
      final projectStats = await _analyticsService.getProjectStats();
      
      setState(() {
        _projects = projects;
        _projectStats = projectStats;
        _isLoading = false;
      });
      
      _fadeController.forward();
    } catch (e) {
      setState(() => _isLoading = false);
    }
  }

  @override
  void dispose() {
    _fadeController.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final theme = Theme.of(context);
    final colorScheme = theme.colorScheme;
    
    if (_isLoading) {
      return Scaffold(
        body: Center(
          child: CircularProgressIndicator(color: colorScheme.primary),
        ),
      );
    }

    return Scaffold(
      body: SafeArea(
        child: FadeTransition(
          opacity: _fadeAnimation,
          child: Column(
            children: [
              // Header
              _buildHeader(context),
              
              // Overview stats
              _buildOverviewStats(context),
              
              // Project list
              Expanded(
                child: _buildProjectList(context),
              ),
            ],
          ),
        ),
      ),
      floatingActionButton: _buildFAB(context),
    );
  }

  Widget _buildHeader(BuildContext context) {
    final theme = Theme.of(context);
    final colorScheme = theme.colorScheme;
    
    return Container(
      padding: const EdgeInsets.all(24),
      child: Column(
        crossAxisAlignment: CrossAxisAlignment.start,
        children: [
          Row(
            children: [
              Expanded(
                child: Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    Text(
                      'Projetos',
                      style: theme.textTheme.headlineSmall?.copyWith(
                        color: colorScheme.onSurface,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                    const SizedBox(height: 4),
                    Text(
                      '${_projects.length} projetos ativos',
                      style: theme.textTheme.bodyMedium?.copyWith(
                        color: colorScheme.onSurface.withOpacity(0.7),
                      ),
                    ),
                  ],
                ),
              ),
              
              // Settings button
              IconButton(
                onPressed: () {
                  // TODO: Show project settings
                },
                icon: Icon(
                  Icons.settings,
                  color: colorScheme.primary,
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildOverviewStats(BuildContext context) {
    final theme = Theme.of(context);
    final colorScheme = theme.colorScheme;
    
    // Calculate overall stats
    int totalTasks = _projectStats.fold(0, (sum, stat) => sum + stat.totalTasks);
    int completedTasks = _projectStats.fold(0, (sum, stat) => sum + stat.completedTasks);
    int overdueTasks = _projectStats.fold(0, (sum, stat) => sum + stat.overdueTasks);
    double overallProgress = totalTasks > 0 ? (completedTasks / totalTasks) * 100 : 0;
    
    return Container(
      margin: const EdgeInsets.symmetric(horizontal: 24),
      padding: const EdgeInsets.all(20),
      decoration: BoxDecoration(
        gradient: LinearGradient(
          begin: Alignment.topLeft,
          end: Alignment.bottomRight,
          colors: [
            colorScheme.primary.withOpacity(0.1),
            colorScheme.primary.withOpacity(0.05),
          ],
        ),
        borderRadius: BorderRadius.circular(20),
        border: Border.all(
          color: colorScheme.primary.withOpacity(0.2),
        ),
      ),
      child: Column(
        children: [
          // Header
          Row(
            children: [
              Icon(
                Icons.analytics,
                color: colorScheme.primary,
                size: 24,
              ),
              const SizedBox(width: 12),
              Text(
                'Visão Geral',
                style: theme.textTheme.titleMedium?.copyWith(
                  color: colorScheme.onSurface,
                  fontWeight: FontWeight.w600,
                ),
              ),
            ],
          ),
          
          const SizedBox(height: 20),
          
          // Progress circle
          Row(
            children: [
              // Circular progress
              SizedBox(
                width: 80,
                height: 80,
                child: Stack(
                  alignment: Alignment.center,
                  children: [
                    CircularProgressIndicator(
                      value: 1.0,
                      strokeWidth: 8,
                      color: colorScheme.surfaceContainerHighest,
                    ),
                    CircularProgressIndicator(
                      value: overallProgress / 100,
                      strokeWidth: 8,
                      color: colorScheme.primary,
                    ),
                    Text(
                      '${overallProgress.toStringAsFixed(0)}%',
                      style: theme.textTheme.titleMedium?.copyWith(
                        color: colorScheme.primary,
                        fontWeight: FontWeight.bold,
                      ),
                    ),
                  ],
                ),
              ),
              
              const SizedBox(width: 24),
              
              // Stats
              Expanded(
                child: Column(
                  children: [
                    Row(
                      children: [
                        Expanded(
                          child: _buildOverviewStatItem(
                            context,
                            icon: Icons.assignment,
                            label: 'Total',
                            value: '$totalTasks',
                            color: colorScheme.onSurface.withOpacity(0.7),
                          ),
                        ),
                        Expanded(
                          child: _buildOverviewStatItem(
                            context,
                            icon: Icons.check_circle,
                            label: 'Concluídas',
                            value: '$completedTasks',
                            color: colorScheme.secondary,
                          ),
                        ),
                      ],
                    ),
                    
                    const SizedBox(height: 12),
                    
                    if (overdueTasks > 0)
                      _buildOverviewStatItem(
                        context,
                        icon: Icons.warning,
                        label: 'Tarefas Atrasadas',
                        value: '$overdueTasks',
                        color: colorScheme.error,
                      ),
                  ],
                ),
              ),
            ],
          ),
        ],
      ),
    );
  }

  Widget _buildOverviewStatItem(
    BuildContext context, {
    required IconData icon,
    required String label,
    required String value,
    required Color color,
  }) {
    final theme = Theme.of(context);
    
    return Row(
      children: [
        Icon(
          icon,
          color: color,
          size: 18,
        ),
        const SizedBox(width: 8),
        Expanded(
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              Text(
                value,
                style: theme.textTheme.titleSmall?.copyWith(
                  color: color,
                  fontWeight: FontWeight.w700,
                ),
              ),
              Text(
                label,
                style: theme.textTheme.labelSmall?.copyWith(
                  color: color.withOpacity(0.8),
                ),
              ),
            ],
          ),
        ),
      ],
    );
  }

  Widget _buildProjectList(BuildContext context) {
    final theme = Theme.of(context);
    final colorScheme = theme.colorScheme;
    
    if (_projects.isEmpty) {
      return _buildEmptyState(context);
    }
    
    return RefreshIndicator(
      onRefresh: _loadData,
      color: colorScheme.primary,
      child: ListView.builder(
        padding: const EdgeInsets.all(24),
        itemCount: _projects.length,
        itemBuilder: (context, index) {
          final project = _projects[index];
          final stats = _projectStats.firstWhere(
            (stat) => stat.project.id == project.id,
            orElse: () => ProjectStats(
              project: project,
              totalTasks: 0,
              completedTasks: 0,
              overdueTasks: 0,
              completionPercentage: 0,
            ),
          );
          
          return ProjectCard(
            project: project,
            stats: stats,
            onTap: () => _openProjectDetails(project),
          );
        },
      ),
    );
  }

  Widget _buildEmptyState(BuildContext context) {
    final theme = Theme.of(context);
    final colorScheme = theme.colorScheme;
    
    return Center(
      child: Padding(
        padding: const EdgeInsets.all(32),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(
              Icons.folder_open,
              size: 64,
              color: colorScheme.primary.withOpacity(0.6),
            ),
            const SizedBox(height: 24),
            Text(
              'Nenhum projeto encontrado',
              style: theme.textTheme.titleLarge?.copyWith(
                color: colorScheme.onSurface,
                fontWeight: FontWeight.w600,
              ),
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 8),
            Text(
              'Crie seu primeiro projeto para organizar suas tarefas',
              style: theme.textTheme.bodyMedium?.copyWith(
                color: colorScheme.onSurface.withOpacity(0.7),
              ),
              textAlign: TextAlign.center,
            ),
            const SizedBox(height: 24),
            ElevatedButton.icon(
              onPressed: _addNewProject,
              icon: const Icon(Icons.add),
              label: const Text('Criar Projeto'),
              style: ElevatedButton.styleFrom(
                backgroundColor: colorScheme.primary,
                foregroundColor: colorScheme.onPrimary,
                padding: const EdgeInsets.symmetric(horizontal: 24, vertical: 12),
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _buildFAB(BuildContext context) {
    final colorScheme = Theme.of(context).colorScheme;
    
    return FloatingActionButton.extended(
      onPressed: _addNewProject,
      backgroundColor: colorScheme.primary,
      foregroundColor: colorScheme.onPrimary,
      icon: const Icon(Icons.add),
      label: const Text('Novo Projeto'),
    );
  }

  void _addNewProject() {
    _showProjectDialog();
  }

  void _openProjectDetails(Project project) {
    // TODO: Navigate to project details page
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text('Abrir projeto: ${project.name}')),
    );
  }

  void _showProjectDialog({Project? project}) {
    final nameController = TextEditingController(text: project?.name ?? '');
    final descriptionController = TextEditingController(text: project?.description ?? '');
    Color selectedColor = project?.color ?? const Color(0xFF1a365d);
    
    final availableColors = [
      const Color(0xFF1a365d), // Navy blue
      const Color(0xFF38a169), // Success green
      const Color(0xFFed8936), // Warning orange
      const Color(0xFFe53e3e), // Error red
      const Color(0xFF6F61EF), // Purple
      const Color(0xFF39D2C0), // Teal
      const Color(0xFF8B5CF6), // Violet
      const Color(0xFFf56565), // Red
    ];
    
    showDialog(
      context: context,
      builder: (context) => StatefulBuilder(
        builder: (context, setDialogState) => AlertDialog(
          title: Text(project == null ? 'Novo Projeto' : 'Editar Projeto'),
          content: SingleChildScrollView(
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                // Name
                TextField(
                  controller: nameController,
                  decoration: const InputDecoration(
                    labelText: 'Nome do projeto',
                    border: OutlineInputBorder(),
                  ),
                ),
                const SizedBox(height: 16),
                
                // Description
                TextField(
                  controller: descriptionController,
                  decoration: const InputDecoration(
                    labelText: 'Descrição (opcional)',
                    border: OutlineInputBorder(),
                  ),
                  maxLines: 3,
                ),
                const SizedBox(height: 16),
                
                // Color picker
                Column(
                  crossAxisAlignment: CrossAxisAlignment.start,
                  children: [
                    const Text('Cor do projeto:'),
                    const SizedBox(height: 12),
                    Wrap(
                      spacing: 12,
                      runSpacing: 12,
                      children: availableColors.map((color) {
                        final isSelected = selectedColor.value == color.value;
                        
                        return GestureDetector(
                          onTap: () {
                            setDialogState(() {
                              selectedColor = color;
                            });
                          },
                          child: Container(
                            width: 40,
                            height: 40,
                            decoration: BoxDecoration(
                              color: color,
                              shape: BoxShape.circle,
                              border: isSelected
                                ? Border.all(
                                    color: Colors.white,
                                    width: 3,
                                  )
                                : null,
                              boxShadow: [
                                BoxShadow(
                                  color: color.withOpacity(0.4),
                                  blurRadius: 8,
                                  offset: const Offset(0, 2),
                                ),
                              ],
                            ),
                            child: isSelected
                              ? const Icon(
                                  Icons.check,
                                  color: Colors.white,
                                  size: 20,
                                )
                              : null,
                          ),
                        );
                      }).toList(),
                    ),
                  ],
                ),
              ],
            ),
          ),
          actions: [
            TextButton(
              onPressed: () => Navigator.pop(context),
              child: const Text('Cancelar'),
            ),
            ElevatedButton(
              onPressed: () {
                if (nameController.text.trim().isNotEmpty) {
                  _saveProject(
                    project: project,
                    name: nameController.text.trim(),
                    description: descriptionController.text.trim(),
                    color: selectedColor,
                  );
                  Navigator.pop(context);
                }
              },
              child: Text(project == null ? 'Criar' : 'Salvar'),
            ),
          ],
        ),
      ),
    );
  }

  Future<void> _saveProject({
    Project? project,
    required String name,
    required String description,
    required Color color,
  }) async {
    // For MVP, we\'ll show a message since project creation/editing 
    // would require updating the DataService
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(project == null 
          ? 'Criação de projetos em desenvolvimento' 
          : 'Edição de projetos em desenvolvimento'),
      ),
    );
  }
}